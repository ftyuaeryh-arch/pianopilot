"""
Drives the 144 LED/m strip on the ESP32-C3 SuperMini over BLE-MIDI.

The calibration math (density / offsets / reverse / shift) is ported
verbatim from Piano-LED-Visualizer's ``lib/functions.py:get_note_position``,
and the default values below are copied from its
``config/default_settings.xml`` (led_count=176, leds_per_meter=144,
shift=0, reverse=0, note_offsets=[[92,2],[55,1]]) — the same numbers
your visualizer install ships with. Adjust them to whatever you've
since tuned in your own `usersettings` if you changed them from
defaults.

The ESP32 firmware is expected to interpret standard Note On/Off MIDI
bytes on channel 1 (right hand) / channel 2 (left hand); see
`note_on`/`note_off` below. If instead your firmware wants a raw LED
index rather than a MIDI note number, use `led_index_for_note()` to
precompute the index and send it as your own custom byte layout.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Tuple

from . import roland_sysex as msg


@dataclass
class LedCalibration:
    """Mirrors Piano-LED-Visualizer's ledstrip/ledsettings state.
    Defaults below are copied straight from config/default_settings.xml.
    """
    leds_per_meter: int = 144
    led_number: int = 176          # total LEDs in the installed strip (led_count)
    reverse: bool = False           # False == 0, True == 1 in the XML
    shift: int = 0                  # global left/right nudge, in LED units
    # [(note_threshold, led_offset), ...] — every entry whose threshold
    # the note exceeds contributes its offset, exactly like ledsettings.py.
    note_offsets: List[Tuple[int, int]] = field(
        default_factory=lambda: [(92, 2), (55, 1)]
    )

    # -- calibration math, ported 1:1 from lib/functions.py:get_note_position --

    def led_index_for_note(self, note: int) -> int:
        note_offset = 0
        for threshold, offset in self.note_offsets:
            if note > threshold:
                note_offset += offset
        note_offset -= self.shift

        density = self.leds_per_meter / 72
        note_pos_raw = int(density * (note - 20) - note_offset)

        if self.reverse:
            return max(0, self.led_number - note_pos_raw)
        return max(0, note_pos_raw)

    # -- live adjustment, ported from ledstrip.py's change_* methods --
    # (there's no on-disk usersettings.json on the phone; these just
    # mutate this dataclass in place — persist it yourself, e.g. by
    # writing it to Kivy's App.user_data_dir, if you want it to survive
    # an app restart.)

    def change_shift(self, value: int, *, fixed: bool = False) -> None:
        self.shift = value if fixed else self.shift + value

    def change_reverse(self, value: int, *, fixed: bool = False) -> None:
        new_val = value if fixed else int(self.reverse) + value
        self.reverse = bool(max(0, min(1, new_val)))

    def change_led_count(self, value: int, *, fixed: bool = False) -> None:
        self.led_number = value if fixed else self.led_number + value
        self.led_number = max(1, self.led_number)

    def add_note_offset(self, threshold: int = 100, offset: int = 1) -> None:
        self.note_offsets.insert(0, (threshold, offset))

    def update_note_offset(self, slot: int, threshold: int, offset: int) -> None:
        self.note_offsets[slot] = (threshold, offset)

    def del_note_offset(self, slot: int) -> None:
        del self.note_offsets[slot]


class LedBridge:
    """Fans NoteOn/NoteOff events out to the ESP32-C3 over the BLE-MIDI
    connection, in lockstep with what the falling-notes canvas draws."""

    def __init__(self, midi_transport, calibration: LedCalibration | None = None):
        self._midi = midi_transport
        self.calibration = calibration or LedCalibration()

    def note_on(self, note: int, velocity: int, hand: int = 0):
        """hand: 0=either/unspecified, 1=right, 2=left — forwarded on
        MIDI channel 1/2 so ESP32 firmware can colour hands differently.
        Sends the raw piano note number; the ESP32 is expected to run
        the same led_index_for_note math (or you can call
        `self.calibration.led_index_for_note(note)` yourself and encode
        the index into your own SysEx/CC scheme instead)."""
        channel = 2 if hand == 2 else 1
        self._midi.send_ble(msg.note_on(channel, note, velocity))

    def note_off(self, note: int, hand: int = 0):
        channel = 2 if hand == 2 else 1
        self._midi.send_ble(msg.note_off(channel, note))

    def all_off(self):
        # Channel Mode: All Notes Off (CC 123) on both hand channels.
        self._midi.send_ble(msg.control_change(1, 123, 0))
        self._midi.send_ble(msg.control_change(2, 123, 0))

    def led_index(self, note: int) -> int:
        """Convenience passthrough for UI code that wants to preview
        where a note will land on the strip (e.g. a calibration screen)."""
        return self.calibration.led_index_for_note(note)
