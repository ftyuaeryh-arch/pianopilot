"""
Wait Mode: listens to incoming USB-MIDI Note On bytes from the Roland
FP-30X (physical key presses) and only lets `SongClock` advance once
every note the song currently expects has been struck. This is the
mobile port of Piano-LED-Visualizer's practice/"Listen" logic in
`learnmidi.py`, simplified to note-matching (no per-hand muting UI yet).
"""
from __future__ import annotations

from typing import Set

from .song_player import SongClock


def parse_incoming(data: bytes):
    """Decodes one raw USB-MIDI packet from AndroidMidi's receiver
    callback into (status_hi, channel, note, velocity) or None."""
    if len(data) < 3:
        return None
    status = data[0] & 0xF0
    channel = (data[0] & 0x0F) + 1
    note, velocity = data[1], data[2]
    return status, channel, note, velocity


class WaitModeController:
    def __init__(self, clock: SongClock):
        self.clock = clock
        self.enabled = False
        self._awaited: Set[int] = set()
        self._struck: Set[int] = set()
        self._refresh_awaited()

    def _refresh_awaited(self):
        pending = self.clock.pending_notes_at_cursor()
        self._awaited = {e.note for e in pending}
        self._struck.clear()
        self.clock.paused = self.enabled and bool(self._awaited)

    def set_enabled(self, enabled: bool):
        self.enabled = enabled
        self._refresh_awaited()

    def on_usb_midi(self, data: bytes):
        """Feed every incoming USB-MIDI packet here (wired to
        AndroidMidi(on_usb_message=wait_mode.on_usb_midi))."""
        if not self.enabled:
            return
        parsed = parse_incoming(data)
        if parsed is None:
            return
        status, _channel, note, velocity = parsed
        if status == 0x90 and velocity > 0:  # Note On
            if note in self._awaited:
                self._struck.add(note)
                if self._struck >= self._awaited:
                    self.clock.paused = False

    def tick_after_advance(self):
        """Call right after `clock.advance(dt)` on every 120Hz frame —
        re-arms the wait gate for the next chord once the player has
        moved past the one that was just released."""
        if not self.enabled:
            return
        pending = self.clock.pending_notes_at_cursor()
        pending_notes = {e.note for e in pending}
        if pending_notes != self._awaited:
            self._refresh_awaited()
