"""
Loads a Standard MIDI File and turns it into a flat, time-stamped list
of note events for the falling-notes canvas + LED bridge to consume.

Note: mido's *file parsing* (mido.MidiFile, merge_tracks, tick2second)
is pure Python and works fine on Android — only mido's realtime I/O
backends (rtmidi/portmidi/pygame) need native libraries we don't have
on the phone. Realtime transport is handled separately by
`android_midi.py`. This mirrors how Piano-LED-Visualizer's
`learnmidi.py` loads songs, but drops its RPi-specific bits.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List

import mido


@dataclass
class NoteEvent:
    time_s: float       # absolute time from song start, seconds
    note: int
    velocity: int
    is_on: bool
    hand: int           # 0=unknown, 1=right, 2=left (by track/channel split)


def get_tempo(mid: mido.MidiFile) -> int:
    for msg in mid:
        if msg.type == "set_tempo":
            return msg.tempo
    return 500000  # 120 BPM default


def load_song(path: str) -> List[NoteEvent]:
    mid = mido.MidiFile(path)

    # Same track->channel assignment trick as learnmidi.py, so a 2-track
    # file (melody/accompaniment or right/left hand) keeps hands separable.
    offset = 1 if len(mid.tracks) == 2 else 0
    for k, track in enumerate(mid.tracks):
        for m in track:
            if not m.is_meta:
                m.channel = k + offset
                if m.type == "note_off":
                    m.velocity = 0

    merged = mido.merge_tracks(mid.tracks)
    tempo = get_tempo(mid)
    ticks_per_beat = mid.ticks_per_beat

    events: List[NoteEvent] = []
    t = 0.0
    for m in merged:
        t += mido.tick2second(m.time, ticks_per_beat, tempo)
        if m.type == "set_tempo":
            tempo = m.tempo
            continue
        if m.type in ("note_on", "note_off"):
            is_on = m.type == "note_on" and m.velocity > 0
            hand = 1 if getattr(m, "channel", 0) == offset else 2
            events.append(NoteEvent(time_s=t, note=m.note, velocity=m.velocity,
                                     is_on=is_on, hand=hand))
    events.sort(key=lambda e: e.time_s)
    return events


class SongClock:
    """Drives playback from Kivy's Clock.schedule_interval at 1/120s.
    Call `advance(dt)` every tick; it yields the events that just
    became due. Supports Wait Mode by exposing `pause_at`/`resume`."""

    def __init__(self, events: List[NoteEvent]):
        self.events = events
        self.position_s = 0.0
        self._cursor = 0
        self.paused = False

    def advance(self, dt: float) -> List[NoteEvent]:
        if self.paused:
            return []
        self.position_s += dt
        due = []
        while self._cursor < len(self.events) and self.events[self._cursor].time_s <= self.position_s:
            due.append(self.events[self._cursor])
            self._cursor += 1
        return due

    def seek(self, seconds: float):
        self.position_s = max(0.0, seconds)
        self._cursor = 0
        while self._cursor < len(self.events) and self.events[self._cursor].time_s < self.position_s:
            self._cursor += 1

    def pending_notes_at_cursor(self) -> List[NoteEvent]:
        """The batch of note_on events the player is currently stalled
        on in Wait Mode (all events sharing the next timestamp)."""
        if self._cursor >= len(self.events):
            return []
        t = self.events[self._cursor].time_s
        i = self._cursor
        batch = []
        while i < len(self.events) and abs(self.events[i].time_s - t) < 1e-6:
            if self.events[i].is_on:
                batch.append(self.events[i])
            i += 1
        return batch
