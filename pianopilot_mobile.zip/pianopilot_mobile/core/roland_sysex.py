"""
Roland FP-30X command builders — ported from PianoPilot's desktop
`messages.py`.

Everything here is re-expressed as plain ``bytes`` (no ``mido``), because
mido's backends (rtmidi/portmidi) are not available on Android. The exact
address maps, checksums and value ranges from the original DT1/RQ1 helpers
are preserved unchanged — only the transport (mido.Message -> raw bytes)
has changed, so behaviour on the piano is identical to the desktop app.

Every function returns one or more ``bytes`` objects, ready to hand to
AndroidMidi.send_usb(...).
"""
from __future__ import annotations

from typing import Iterable, List, Tuple

from . import tone_catalog

ROLAND_ID = 0x41
ROLAND_DEVICE_ID = 0x10
FP30X_MODEL_ID = (0x00, 0x00, 0x00, 0x28)
ROLAND_CMD_RQ1 = 0x11
ROLAND_CMD_DT1 = 0x12

MASTER_VOLUME_DT1_MAX = 100

MIDI_DUAL_MAIN_VOLUME_CH = 4
MIDI_DUAL_LAYER_VOLUME_CH = 2
MIDI_SPLIT_RIGHT_VOLUME_CH = MIDI_DUAL_MAIN_VOLUME_CH
MIDI_SPLIT_LEFT_VOLUME_CH = MIDI_DUAL_LAYER_VOLUME_CH
POST_PROGRAM_CHANGE_LATCH_DELAY_S = 0.08
DEFAULT_MESSAGE_GAP_S = 0.02


def channel_zero(channel_1_16: int) -> int:
    if not 1 <= channel_1_16 <= 16:
        raise ValueError("MIDI channel must be between 1 and 16")
    return channel_1_16 - 1


def roland_checksum(values: Iterable[int]) -> int:
    return (128 - (sum(values) % 128)) % 128


def _sysex(*data: int) -> bytes:
    return bytes((0xF0, *data, 0xF7))


def roland_data_set_1(address: Tuple[int, int, int, int], data: Iterable[int]) -> bytes:
    data_tuple = tuple(data)
    payload = [*address, *data_tuple]
    return _sysex(
        ROLAND_ID, ROLAND_DEVICE_ID, *FP30X_MODEL_ID, ROLAND_CMD_DT1,
        *payload, roland_checksum(payload),
    )


def roland_data_request_1(address: Tuple[int, int, int, int], size: Tuple[int, int, int, int]) -> bytes:
    payload = [*address, *size]
    return _sysex(
        ROLAND_ID, ROLAND_DEVICE_ID, *FP30X_MODEL_ID, ROLAND_CMD_RQ1,
        *payload, roland_checksum(payload),
    )


def control_change(channel_1_16: int, control: int, value: int) -> bytes:
    ch = channel_zero(channel_1_16)
    if not 0 <= control <= 127 or not 0 <= value <= 127:
        raise ValueError("Control and value must be 0-127")
    return bytes((0xB0 | ch, control, value))


def program_change(channel_1_16: int, program_0_127: int) -> bytes:
    ch = channel_zero(channel_1_16)
    return bytes((0xC0 | ch, program_0_127))


def note_on(channel_1_16: int, note: int, velocity: int) -> bytes:
    return bytes((0x90 | channel_zero(channel_1_16), note, velocity))


def note_off(channel_1_16: int, note: int, velocity: int = 0) -> bytes:
    return bytes((0x80 | channel_zero(channel_1_16), note, velocity))


# --- Handshake / connection ------------------------------------------------

def app_connect_handshake() -> bytes:
    """DT1 'connection' 01 00 03 06 = 1. Required before the FP-30X will
    accept master-volume / metronome DT1 writes."""
    return roland_data_set_1((0x01, 0x00, 0x03, 0x06), (0x01,))


# --- Master volume -----------------------------------------------------

def master_volume_set(value: int) -> bytes:
    if not 0 <= value <= MASTER_VOLUME_DT1_MAX:
        raise ValueError(f"Master Volume must be 0-{MASTER_VOLUME_DT1_MAX}")
    return roland_data_set_1((0x01, 0x00, 0x02, 0x13), (value,))


def master_volume_read() -> bytes:
    return roland_data_request_1((0x01, 0x00, 0x02, 0x13), (0x00, 0x00, 0x00, 0x01))


def master_volume_realtime(value_0_127: int) -> bytes:
    if not 0 <= value_0_127 <= 127:
        raise ValueError("Master Volume must be 0-127")
    return _sysex(0x7F, 0x7F, 0x04, 0x01, 0x00, value_0_127)


# --- Keyboard mode / tones -----------------------------------------------

def keyboard_mode_set(mode: int) -> bytes:
    """0=Single 1=Split 2=Dual 3=Twin"""
    if not 0 <= mode <= 3:
        raise ValueError("keyboard mode must be 0-3")
    return roland_data_set_1((0x01, 0x00, 0x02, 0x00), (mode,))


def tone_for_single_set(category_idx: int, num: int) -> bytes:
    return roland_data_set_1((0x01, 0x00, 0x02, 0x07), (category_idx, num // 128, num % 128))


def tone_for_split_set(category_idx: int, num: int) -> bytes:
    return roland_data_set_1((0x01, 0x00, 0x02, 0x0A), (category_idx, num // 128, num % 128))


def tone_for_dual_set(category_idx: int, num: int) -> bytes:
    return roland_data_set_1((0x01, 0x00, 0x02, 0x0D), (category_idx, num // 128, num % 128))


def bank_select_program_and_latch(
    channel_1_16: int, bank_msb: int, bank_lsb: int, program_0_127: int,
    *, latch_after_program: bool = True, latch_note: int = 60, latch_velocity: int = 1,
) -> Tuple[List[bytes], List[bytes]]:
    """Low-level bank-select+PC+latch builder. Returns (core, latch) —
    send `core`, wait POST_PROGRAM_CHANGE_LATCH_DELAY_S, then send
    `latch` (a very short Note On/Off) because the FP-30X only swaps
    the tone on the next Note On after the Program Change.

    Prefer `hidden_gs_tone_select()` below, which looks the bank/program
    up from the real tone catalog instead of taking raw numbers.
    """
    if not 0 <= bank_msb <= 127 or not 0 <= bank_lsb <= 127:
        raise ValueError("Bank MSB/LSB must be 0-127")
    core = [
        control_change(channel_1_16, 0, bank_msb),
        control_change(channel_1_16, 32, bank_lsb),
        program_change(channel_1_16, program_0_127),
    ]
    if not latch_after_program:
        return core, []
    latch = [
        note_on(channel_1_16, latch_note, latch_velocity),
        note_off(channel_1_16, latch_note, 0),
    ]
    return core, latch


def hidden_gs_tone_select(
    tone: "tone_catalog.Tone",
    channel_1_16: int = 1,
    *, latch_note: int = 60, latch_velocity: int = 1,
) -> Tuple[List[bytes], List[bytes]]:
    """Hidden GS/GM2 tone select via CC0/CC32/PC, using a `Tone` from
    the real catalog (`core/tone_catalog.py`, 176 tones ported from
    your desktop app's Tone List / GM2 reverse-engineering). Returns
    (core, latch) exactly like `bank_select_program_and_latch` — send
    `core`, wait `POST_PROGRAM_CHANGE_LATCH_DELAY_S`, then send `latch`.
    """
    return bank_select_program_and_latch(
        channel_1_16, tone.bank_msb, tone.bank_lsb, tone.program_midi,
        latch_after_program=True, latch_note=latch_note, latch_velocity=latch_velocity,
    )


def dt1_tone_select(tone: "tone_catalog.Tone", mode: str = "single") -> bytes:
    """In-category DT1 tone select — the same mechanism as the panel's
    own Single/Split/Dual tone pickers (`01 00 02 07/0A/0D`), addressed
    by [category_idx, num_hi, num_lo] via tone_catalog.tone_dt1_encoding.
    mode: "single" | "split" | "dual".
    """
    cat_idx, num_hi, num_lo = tone_catalog.tone_dt1_encoding(tone)
    address = {
        "single": (0x01, 0x00, 0x02, 0x07),
        "split": (0x01, 0x00, 0x02, 0x0A),
        "dual": (0x01, 0x00, 0x02, 0x0D),
    }[mode]
    return roland_data_set_1(address, (cat_idx, num_hi, num_lo))


# --- Split / Dual balance --------------------------------------------------

def split_balance_sysex_byte(value: int) -> int:
    v = max(0, min(18, int(value)))
    return max(0, min(127, 64 + (v - 9)))


def split_balance_set(value: int) -> bytes:
    return roland_data_set_1((0x01, 0x00, 0x02, 0x03), (split_balance_sysex_byte(value),))


def split_balance_control_changes(value: int) -> List[bytes]:
    v = max(0, min(18, int(value)))
    d = v - 9
    left = max(1, min(127, 100 - d))
    right = max(1, min(127, 100 + d))
    return [
        control_change(MIDI_SPLIT_LEFT_VOLUME_CH, 7, left),
        control_change(MIDI_SPLIT_RIGHT_VOLUME_CH, 7, right),
    ]


# --- Metronome --------------------------------------------------------

def metronome_set(*, on: bool) -> bytes:
    return roland_data_set_1((0x01, 0x00, 0x03, 0x1A), (0x01 if on else 0x00,))


def metronome_set_tempo(bpm: int) -> bytes:
    if not 10 <= bpm <= 500:
        raise ValueError("Tempo must be 10-500 BPM")
    return roland_data_set_1((0x01, 0x00, 0x03, 0x09), (bpm // 128, bpm % 128))
