"""
Android MIDI transport.

Design decision: instead of hand-rolling a USB-host bulk-transfer driver
*and* a separate BLE GATT client (the two protocols are very different),
this uses Android's built-in ``android.media.midi.MidiManager``
(API 23+). Since Android 8.0, MidiManager also auto-wraps a paired
BLE-MIDI peripheral (the ESP32-C3 running a standard BLE-MIDI service)
as a regular ``MidiDevice`` — so USB-OTG and BLE endpoints are opened,
read and written with the *same* code path.

Binding to the BLE peripheral reliably (item 3): a freshly-paired
BLE-MIDI device does not always show up in the very first
``getDevices()`` snapshot — Android needs a moment to bring up the
virtual MidiDevice after the GATT bond completes. `open_ble()` below
therefore does not just poll once; it registers a
``MidiManager.DeviceCallback`` and reacts to ``onDeviceAdded`` if the
device isn't already present, with a bounded wait. This is the same
technique Google's own MIDI sample apps use for BLE-MIDI ("Bluetooth
peripherals may not show up in getDevices() immediately").

Requires (in buildozer.spec, see requirements):
    pyjnius, android permissions BLUETOOTH_CONNECT/SCAN, and the
    android.hardware.usb.host feature.

This module is Android-only. On desktop it degrades to a no-op stub so
the rest of the app (UI, song parsing) can still be developed/tested
on a PC.
"""
from __future__ import annotations

import threading
from typing import Callable, Optional

try:
    from jnius import autoclass, PythonJavaClass, java_method
    ANDROID = True
except Exception:  # running on desktop for dev/testing
    ANDROID = False


NoteCallback = Callable[[bytes], None]

# Default expected advertised/paired name of your ESP32-C3 BLE-MIDI
# peripheral. Set this to whatever name string your firmware calls
# `BLEMidiServer.begin("...")` (or equivalent) with.
DEFAULT_BLE_DEVICE_NAME = "PianoPilot BLE LED"
DEFAULT_USB_DEVICE_NAME = "FP-30X"

BLE_OPEN_TIMEOUT_S = 8.0
USB_OPEN_TIMEOUT_S = 5.0

MIDI_DEVICE_TYPE_USB = 1
MIDI_DEVICE_TYPE_VIRTUAL = 2
MIDI_DEVICE_TYPE_BLUETOOTH = 3


class _NullTransport:
    """Desktop fallback so the app boots without a phone attached."""

    def __init__(self, *_a, **_kw):
        self.connected = False

    def open_usb(self, *_a, **_kw):
        return False

    def open_ble(self, *_a, **_kw):
        return False

    def send_usb(self, _data: bytes):
        pass

    def send_ble(self, _data: bytes):
        pass

    def close(self):
        pass


class AndroidMidi:
    """Owns up to two open MIDI device connections: one for the Roland
    FP-30X (wired, USB-OTG host) and one for the ESP32-C3 LED
    controller (wireless, BLE-MIDI)."""

    def __init__(self, on_usb_message: Optional[NoteCallback] = None):
        self.on_usb_message = on_usb_message
        self._usb_in_port = None
        self._usb_out_port = None
        self._ble_out_port = None
        self._usb_device = None
        self._ble_device = None
        self._device_callback = None  # keep a strong ref, GC will drop it otherwise
        self._receiver = None
        self._lock = threading.Lock()

        if ANDROID:
            self._PythonActivity = autoclass("org.kivy.android.PythonActivity")
            self._Context = autoclass("android.content.Context")
            self._Handler = autoclass("android.os.Handler")
            activity = self._PythonActivity.mActivity
            self._activity = activity
            self._midi_manager = activity.getSystemService(self._Context.MIDI_SERVICE)
        else:
            self._midi_manager = None

    # ---- device discovery ---------------------------------------------------

    def list_devices(self):
        """Returns [(index, name, device_type)] for every MIDI device
        Android currently knows about (both transports show up here).
        device_type: 1=USB, 2=VIRTUAL, 3=BLUETOOTH."""
        if not ANDROID:
            return []
        infos = self._midi_manager.getDevices()
        out = []
        for i, info in enumerate(infos):
            props = info.getProperties()
            name = props.getString("name", "unknown") if props else "unknown"
            out.append((i, name, info.getType()))
        return out

    def open_usb(self, name_contains: str = DEFAULT_USB_DEVICE_NAME) -> bool:
        """Opens the wired Roland connection."""
        return self._open_matching(name_contains, MIDI_DEVICE_TYPE_USB, USB_OPEN_TIMEOUT_S)

    def open_ble(self, name_contains: str = DEFAULT_BLE_DEVICE_NAME) -> bool:
        """Opens the wireless BLE-MIDI connection to the LED
        controller. The ESP32-C3 must already be *paired* in Android
        Bluetooth settings first — MidiManager only surfaces paired
        BLE-MIDI peripherals as MidiDevice objects, it will not do
        BLE scanning/pairing itself. Waits up to BLE_OPEN_TIMEOUT_S for
        the device to appear, since it can enumerate a moment late."""
        return self._open_matching(name_contains, MIDI_DEVICE_TYPE_BLUETOOTH, BLE_OPEN_TIMEOUT_S)

    def _find_info(self, name_contains: str, device_type: int):
        for info in self._midi_manager.getDevices():
            props = info.getProperties()
            name = props.getString("name", "") if props else ""
            if name_contains.lower() in name.lower() and info.getType() == device_type:
                return info
        return None

    def _open_matching(self, name_contains: str, device_type: int, timeout_s: float) -> bool:
        if not ANDROID:
            return False

        target_info = self._find_info(name_contains, device_type)

        if target_info is None:
            # Not enumerated yet (common right after BLE bonding) —
            # register a DeviceCallback and wait for onDeviceAdded.
            target_info = self._wait_for_device(name_contains, device_type, timeout_s)

        if target_info is None:
            return False

        device = self._open_device_info(target_info, timeout_s)
        if device is None:
            return False

        info = device.getInfo()
        if info.getOutputPortCount() < 1:
            return False
        out_port = device.openOutputPort(0)

        if device_type == MIDI_DEVICE_TYPE_USB:
            self._usb_device, self._usb_out_port = device, out_port
            if info.getInputPortCount() > 0 and self.on_usb_message is not None:
                self._usb_in_port = device.openInputPort(0)
                self._attach_receiver(self._usb_in_port)
        else:
            self._ble_device, self._ble_out_port = device, out_port
        return True

    def _wait_for_device(self, name_contains: str, device_type: int, timeout_s: float):
        """Registers MidiManager.DeviceCallback and blocks (off the UI
        thread — call open_usb/open_ble from a worker thread) until a
        matching device appears in onDeviceAdded, or timeout."""
        found = {}
        done = threading.Event()

        class _DeviceCallback(PythonJavaClass):
            __javainterfaces__ = ["android/media/midi/MidiManager$DeviceCallback"]
            __javacontext__ = "app"

            @java_method("(Landroid/media/midi/MidiDeviceInfo;)V")
            def onDeviceAdded(self, device_info):
                props = device_info.getProperties()
                name = props.getString("name", "") if props else ""
                if name_contains.lower() in name.lower() and device_info.getType() == device_type:
                    found["info"] = device_info
                    done.set()

            @java_method("(Landroid/media/midi/MidiDeviceInfo;)V")
            def onDeviceRemoved(self, device_info):
                pass

        handler = self._Handler(self._activity.getMainLooper())
        callback = _DeviceCallback()
        self._device_callback = callback  # hold a reference
        self._midi_manager.registerDeviceCallback(callback, handler)
        try:
            # Re-check in case the device landed between our first
            # getDevices() call and registering the callback.
            existing = self._find_info(name_contains, device_type)
            if existing is not None:
                return existing
            done.wait(timeout=timeout_s)
            return found.get("info")
        finally:
            self._midi_manager.unregisterDeviceCallback(callback)

    def _open_device_info(self, target_info, timeout_s: float):
        done = threading.Event()
        result = {}

        class _OpenCallback(PythonJavaClass):
            __javainterfaces__ = ["android/media/midi/MidiManager$OnDeviceOpenedListener"]
            __javacontext__ = "app"

            @java_method("(Landroid/media/midi/MidiDevice;)V")
            def onDeviceOpened(self, device):
                result["device"] = device
                done.set()

        handler = self._Handler(self._activity.getMainLooper())
        self._midi_manager.openDevice(target_info, _OpenCallback(), handler)
        done.wait(timeout=timeout_s)
        return result.get("device")

    def _attach_receiver(self, input_port):
        """Wires incoming USB-MIDI bytes (key presses from the physical
        piano) back into Python for Wait Mode."""
        on_message = self.on_usb_message

        class _Receiver(PythonJavaClass):
            __javainterfaces__ = ["android/media/midi/MidiReceiver"]
            __javacontext__ = "app"

            @java_method("([BIII)V")
            def onSend(self, data, offset, count, timestamp):
                payload = bytes(data[offset:offset + count])
                if on_message:
                    on_message(payload)

        self._receiver = _Receiver()  # keep a strong ref
        input_port.connect(self._receiver)

    # ---- sending --------------------------------------------------------

    def send_usb(self, data: bytes):
        """Sends raw MIDI/SysEx bytes to the Roland over the wired
        USB-OTG connection (key tracking output + hidden-tone SysEx)."""
        if not ANDROID or self._usb_out_port is None:
            return
        with self._lock:
            self._usb_out_port.send(bytearray(data), 0, len(data))

    def send_ble(self, data: bytes):
        """Sends Note On/Off bytes to the ESP32-C3 over BLE-MIDI to
        drive the LED strip."""
        if not ANDROID or self._ble_out_port is None:
            return
        with self._lock:
            self._ble_out_port.send(bytearray(data), 0, len(data))

    @property
    def usb_ready(self) -> bool:
        return self._usb_out_port is not None

    @property
    def ble_ready(self) -> bool:
        return self._ble_out_port is not None

    def close(self):
        for port in (self._usb_in_port, self._usb_out_port, self._ble_out_port):
            try:
                if port is not None:
                    port.close()
            except Exception:
                pass
        for device in (self._usb_device, self._ble_device):
            try:
                if device is not None:
                    device.close()
            except Exception:
                pass


def make_midi(on_usb_message: Optional[NoteCallback] = None):
    return AndroidMidi(on_usb_message) if ANDROID else _NullTransport(on_usb_message)
