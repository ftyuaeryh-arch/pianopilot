"""
Requests the "dangerous" runtime permissions BLE-MIDI needs, on top of
the manifest entries in buildozer.spec. Declaring a permission in the
manifest only lets Android *offer* it — BLUETOOTH_CONNECT, BLUETOOTH_SCAN
and ACCESS_FINE_LOCATION must also be granted via the runtime dialog
before MidiManager.openDevice() will successfully bind to the BLE-MIDI
peripheral. Without this step, open_ble() in android_midi.py will
either silently fail to enumerate the device or throw a SecurityException
on some OEM builds (Samsung's One UI included).
"""
from __future__ import annotations

try:
    from android.permissions import request_permissions, check_permission, Permission
    ANDROID = True
except Exception:
    ANDROID = False


BLE_PERMISSIONS = [
    "android.permission.BLUETOOTH_CONNECT",
    "android.permission.BLUETOOTH_SCAN",
    "android.permission.ACCESS_FINE_LOCATION",
]


def ensure_ble_permissions(on_result=None):
    """Call this once, e.g. from PianoPilotApp.build() or right before
    the user taps "Connect BLE", *before* AndroidMidi.open_ble(). On
    API < 31 the Bluetooth permissions are no-ops (auto-granted at
    install time) but ACCESS_FINE_LOCATION is still requested since
    it's required for BLE on those versions too.

    on_result: optional callback(permissions: list[str], grants: list[bool])
    invoked once the user answers the system dialog (plyer/pyjnius'
    `android.permissions` module delivers this asynchronously).
    """
    if not ANDROID:
        if on_result:
            on_result(BLE_PERMISSIONS, [True] * len(BLE_PERMISSIONS))
        return

    missing = [p for p in BLE_PERMISSIONS if not check_permission(p)]
    if not missing:
        if on_result:
            on_result(BLE_PERMISSIONS, [True] * len(BLE_PERMISSIONS))
        return

    request_permissions(missing, on_result)


def has_ble_permissions() -> bool:
    if not ANDROID:
        return True
    return all(check_permission(p) for p in BLE_PERMISSIONS)
