"""
PianoPilot Mobile — entry point.

Ties together:
  core/android_midi.py  -> two concurrent MIDI connections (USB host to
                            the Roland FP-30X, BLE-MIDI to the ESP32-C3)
  core/roland_sysex.py  -> exact SysEx/CC command builders from the
                            desktop PianoPilot app
  core/song_player.py   -> .mid file loading + a 120Hz-driven SongClock
  core/wait_mode.py      -> freezes playback until the right keys are hit
  core/led_bridge.py     -> mirrors note events to the LED strip over BLE
  ui/falling_notes.py    -> the on-screen falling-notes canvas
"""
from __future__ import annotations

import os
import threading

from kivy.app import App
from kivy.clock import Clock
from kivy.properties import BooleanProperty, StringProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.filechooser import FileChooserListView
from kivy.uix.popup import Popup

from core import roland_sysex as sx
from core import tone_catalog
from core.android_midi import make_midi
from core.android_permissions import ensure_ble_permissions, has_ble_permissions
from core.song_player import load_song, SongClock, NoteEvent
from core.wait_mode import WaitModeController
from core.led_bridge import LedBridge, LedCalibration
from ui.falling_notes import FallingNotesWidget, FallingNote

FRAME_HZ = 120.0
FRAME_S = 1.0 / FRAME_HZ


class RootLayout(BoxLayout):
    pass


class PianoPilotApp(App):
    usb_connected = BooleanProperty(False)
    ble_connected = BooleanProperty(False)
    selected_tone_name = StringProperty("Concert Piano")

    def build(self):
        self.title = "PianoPilot Mobile"
        self.clock: SongClock | None = None
        self.wait_mode: WaitModeController | None = None
        self.playing = False
        self._gs_tone_idx = 0

        # USB input (physical key presses) feeds Wait Mode + lights the
        # falling-notes key strip in real time.
        self.midi = make_midi(on_usb_message=self._on_usb_message)
        self.led_bridge = LedBridge(self.midi, LedCalibration())

        root = RootLayout()
        self.falling_notes: FallingNotesWidget = root.ids.falling_notes

        Clock.schedule_interval(self._on_frame, FRAME_S)
        return root

    # ---- connections ------------------------------------------------------

    def connect_usb(self):
        def _worker():
            ok = self.midi.open_usb("FP-30X")
            self.usb_connected = ok
            if ok:
                self.midi.send_usb(sx.app_connect_handshake())
        threading.Thread(target=_worker, daemon=True).start()

    def connect_ble(self):
        # Pair "PianoPilot BLE LED" in Android Bluetooth settings first —
        # MidiManager only surfaces already-paired BLE-MIDI peripherals.
        def _do_open():
            def _worker():
                ok = self.midi.open_ble()  # default name: android_midi.DEFAULT_BLE_DEVICE_NAME
                self.ble_connected = ok
            threading.Thread(target=_worker, daemon=True).start()

        if has_ble_permissions():
            _do_open()
        else:
            # Runtime dialog is async; open_ble() only runs once the
            # user has answered it (grants is a list[bool] matching
            # core.android_permissions.BLE_PERMISSIONS order).
            def _on_result(_permissions, grants):
                if all(grants):
                    _do_open()
                else:
                    self.ble_connected = False
            ensure_ble_permissions(_on_result)

    # ---- USB input (Wait Mode + key lights) --------------------------------

    def _on_usb_message(self, data: bytes):
        if self.wait_mode is not None:
            self.wait_mode.on_usb_midi(data)
        if len(data) >= 3:
            status, note, vel = data[0] & 0xF0, data[1], data[2]
            if status == 0x90 and vel > 0:
                self.falling_notes.pressed_notes.add(note)
            elif status in (0x80, 0x90):  # note off, or note-on vel 0
                self.falling_notes.pressed_notes.discard(note)

    # ---- controls (mapped to Roland SysEx, exact bytes from PianoPilot) ---

    def on_master_volume(self, value):
        self.midi.send_usb(sx.master_volume_set(int(value)))

    def on_balance(self, value):
        self.midi.send_usb(sx.split_balance_set(int(value)))
        for cc in sx.split_balance_control_changes(int(value)):
            self.midi.send_usb(cc)

    def change_gs_tone(self, direction: int):
        """Steps through the full 176-tone catalog (core/tone_catalog.py,
        ported from your desktop app's Tone List / GM2 table) and sends
        the real bank-select + program-change + latch sequence."""
        self._gs_tone_idx = (self._gs_tone_idx + direction) % len(tone_catalog.TONE_PRESETS)
        tone = tone_catalog.tone_at(self._gs_tone_idx)
        self.selected_tone_name = tone.name  # bind a Label to this in the .kv if desired

        core, latch = sx.hidden_gs_tone_select(tone, channel_1_16=1)
        for m in core:
            self.midi.send_usb(m)
        Clock.schedule_once(lambda *_: [self.midi.send_usb(m) for m in latch],
                             sx.POST_PROGRAM_CHANGE_LATCH_DELAY_S)

    def on_wait_mode_toggle(self, enabled: bool):
        if self.wait_mode is not None:
            self.wait_mode.set_enabled(enabled)

    # ---- song loading / playback -------------------------------------------

    def open_song_chooser(self):
        chooser = FileChooserListView(path=os.path.expanduser("~"), filters=["*.mid", "*.midi"])
        popup = Popup(title="Choose a song", content=chooser, size_hint=(0.9, 0.9))

        def _selected(_instance, selection, *_a):
            if selection:
                self.load_song_file(selection[0])
                popup.dismiss()
        chooser.bind(on_submit=_selected)
        popup.open()

    def load_song_file(self, path: str):
        events = load_song(path)
        self.clock = SongClock(events)
        self.wait_mode = WaitModeController(self.clock)
        self._all_events = events
        self.playing = False

    def toggle_play(self):
        self.playing = not self.playing

    # ---- 120Hz frame tick ---------------------------------------------------

    def _on_frame(self, dt: float):
        if self.clock is None:
            return

        if self.playing:
            due = self.clock.advance(dt)
            if self.wait_mode is not None:
                self.wait_mode.tick_after_advance()
            for ev in due:
                if ev.is_on:
                    self.led_bridge.note_on(ev.note, ev.velocity, ev.hand)
                else:
                    self.led_bridge.note_off(ev.note, ev.hand)

        window = self.clock.position_s + FallingNotesWidget.LOOKAHEAD_S
        visible = [
            FallingNote(e.note, e.time_s, e.time_s + 0.4, e.hand)
            for e in self._all_events
            if self.clock.position_s - 0.5 <= e.time_s <= window and e.is_on
        ] if hasattr(self, "_all_events") else []
        self.falling_notes.load_upcoming(visible)
        self.falling_notes.set_time(self.clock.position_s)
        self.falling_notes.redraw()

    def on_stop(self):
        self.midi.close()


if __name__ == "__main__":
    PianoPilotApp().run()
