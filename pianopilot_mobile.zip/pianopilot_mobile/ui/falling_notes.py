"""
Falling-notes canvas. Ported concept from Piano-LED-Visualizer's
gaming-mode LED canvas, but drawn as Kivy graphics instructions instead
of addressing an LED strip directly (the LED strip is driven in
parallel and independently by `led_bridge.py` over BLE, see
`main.py::PianoPilotApp.on_song_frame`).

Layout: 88 keys (A0=21 .. C8=108) spread across the widget width,
notes fall top -> bottom and are "hit" at the key-strip line.
"""
from __future__ import annotations

from kivy.uix.widget import Widget
from kivy.graphics import Color, Rectangle
from kivy.clock import Clock

FIRST_NOTE = 21   # A0
LAST_NOTE = 108   # C8
NUM_KEYS = LAST_NOTE - FIRST_NOTE + 1

# Sharps get a slightly darker, narrower key — same white/black key
# pattern used to size LED note offsets in the desktop visualizer.
_BLACK_KEY_PC = {1, 3, 6, 8, 10}


class FallingNote:
    __slots__ = ("note", "start_s", "end_s", "hand")

    def __init__(self, note: int, start_s: float, end_s: float, hand: int):
        self.note = note
        self.start_s = start_s
        self.end_s = end_s
        self.hand = hand


class FallingNotesWidget(Widget):
    LOOKAHEAD_S = 2.5  # seconds of song visible above the key strip
    KEY_STRIP_HEIGHT = 90

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.active_notes: list[FallingNote] = []  # notes currently on-screen
        self.pressed_notes: set[int] = set()        # lit up from USB key input
        self._current_time_s = 0.0
        self.bind(size=lambda *_: self.redraw(), pos=lambda *_: self.redraw())

    def load_upcoming(self, notes: list[FallingNote]):
        """Called once per song load / seek with every note whose
        [start,end] falls inside the lookahead window; main.py trims
        this list forward each frame as time advances."""
        self.active_notes = notes

    def set_time(self, t: float):
        self._current_time_s = t

    def key_x(self, note: int) -> float:
        idx = note - FIRST_NOTE
        return self.x + (idx / NUM_KEYS) * self.width

    def key_width(self) -> float:
        return self.width / NUM_KEYS

    def redraw(self):
        """Rebuilds the canvas. Called every frame at 120Hz from
        main.py's Clock.schedule_interval — kept intentionally simple
        (flat Rectangle draws, no shaders) so it stays cheap enough
        for a mid-range phone GPU at that refresh rate."""
        self.canvas.clear()
        kw = self.key_width()
        strip_top = self.y + self.KEY_STRIP_HEIGHT

        with self.canvas:
            # key strip background
            Color(0.08, 0.08, 0.1, 1)
            Rectangle(pos=(self.x, self.y), size=(self.width, self.KEY_STRIP_HEIGHT))

            # falling note blocks
            for n in self.active_notes:
                rel_start = n.start_s - self._current_time_s
                rel_end = n.end_s - self._current_time_s
                if rel_end < 0 or rel_start > self.LOOKAHEAD_S:
                    continue
                y_top = strip_top + (self.LOOKAHEAD_S - rel_start) / self.LOOKAHEAD_S * (self.height - self.KEY_STRIP_HEIGHT)
                y_bot = strip_top + (self.LOOKAHEAD_S - rel_end) / self.LOOKAHEAD_S * (self.height - self.KEY_STRIP_HEIGHT)
                y_bot = max(y_bot, strip_top)
                if n.hand == 2:
                    Color(0.95, 0.35, 0.25, 0.9)
                else:
                    Color(0.25, 0.65, 0.95, 0.9)
                Rectangle(pos=(self.key_x(n.note), min(y_top, y_bot)),
                          size=(kw * 0.9, abs(y_top - y_bot)))

            # key strip keys, lit if currently pressed (from USB input)
            for note in range(FIRST_NOTE, LAST_NOTE + 1):
                is_black = (note % 12) in _BLACK_KEY_PC
                if note in self.pressed_notes:
                    Color(0.2, 1.0, 0.4, 1)
                elif is_black:
                    Color(0.15, 0.15, 0.17, 1)
                else:
                    Color(0.85, 0.85, 0.85, 1)
                h = self.KEY_STRIP_HEIGHT * (0.6 if is_black else 1.0)
                Rectangle(pos=(self.key_x(note), self.y), size=(kw * 0.92, h))
