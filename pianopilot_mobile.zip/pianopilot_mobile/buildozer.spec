[app]
title = PianoPilot Mobile
package.name = pianopilotmobile
package.domain = org.pianopilot

source.dir = .
source.include_exts = py,kv,png,jpg,atlas,mid,midi,xml

version = 0.1.0

# mido is pure-python for .mid file parsing (no rtmidi/portmidi backend
# pulled in, so no native audio-lib recipe needed); pyjnius gives
# access to android.media.midi.MidiManager for both the USB-OTG and
# BLE-MIDI transports (see core/android_midi.py).
requirements = python3,kivy==2.3.0,pyjnius,mido

orientation = landscape
fullscreen = 1

icon.filename = %(source.dir)s/assets/icon.png

# --- Android platform -------------------------------------------------------

android.api = 34
# minapi 26 (Android 8.0 / O) is a hard requirement, NOT just a nice
# minimum: MidiManager only auto-wraps a paired BLE-MIDI peripheral as
# a MidiDevice starting on O. Below API 26 the BLE-MIDI half of this
# app (core/android_midi.py::open_ble) cannot work at all.
android.minapi = 26
android.ndk = 25b
android.archs = arm64-v8a
android.allow_backup = 1

# --- Permissions -------------------------------------------------------------
# Grouped by what each is for, since this app genuinely needs both the
# legacy (API <=30) and modern (API 31+) Bluetooth permission sets:
#
#   USB-OTG (wired Roland FP-30X)
#     - no manifest permission is needed to *call* MidiManager for USB;
#       Android prompts the user with its own "Allow app to access
#       USB device?" system dialog the first time, per device.
#     - android.hardware.usb.host (uses-feature, below) declares the
#       app as a USB-host-capable client so the Play Store / OS don't
#       filter it out on devices without USB-OTG hardware.
#
#   BLE-MIDI (wireless ESP32-C3 LED controller)
#     - BLUETOOTH / BLUETOOTH_ADMIN: legacy permissions, required on
#       API <= 30 to use Bluetooth at all (harmless to also declare on
#       newer APIs; the OS ignores them there).
#     - BLUETOOTH_CONNECT: required on API 31+ (Android 12) to connect
#       to an already-bonded Bluetooth device — this is the one that
#       actually gates MidiManager.openDevice() on the BLE MidiDevice
#       on a Galaxy A53 (One UI ships Android 12+).
#     - BLUETOOTH_SCAN: not strictly needed for *opening* an
#       already-paired MIDI device, but Android 12+ requires it if the
#       app itself ever calls BluetoothAdapter.startDiscovery() /
#       queries paired-device metadata — kept in for headroom if you
#       add an in-app "find nearby ESP32" pairing flow later.
#     - ACCESS_FINE_LOCATION: required by API < 31 for *any* BLE scan
#       (Android tied BLE scanning to location permission before the
#       BLUETOOTH_SCAN permission existed). Not needed just to open an
#       already-paired MidiDevice, but harmless to request.
#
# At runtime, BLUETOOTH_CONNECT/SCAN and ACCESS_FINE_LOCATION are
# "dangerous" permissions on API 23+ and must also be requested via
# Android's runtime permission dialog (e.g. with pyjnius calling
# Activity.requestPermissions(), or the plyer permissions API) before
# connect_ble() is called — declaring them here only makes the OS
# *allow* asking for them, it does not grant them.
android.permissions =
    android.permission.BLUETOOTH,
    android.permission.BLUETOOTH_ADMIN,
    android.permission.BLUETOOTH_CONNECT,
    android.permission.BLUETOOTH_SCAN,
    android.permission.ACCESS_FINE_LOCATION,
    android.permission.FOREGROUND_SERVICE

# Hardware/feature declarations:
#   - usb.host: required=false so devices/stores don't hard-filter the
#     app out (some phones without OTG could still install it and use
#     BLE-only mode); the app checks USB availability at runtime.
#   - bluetooth_le: required=true — there's no fallback transport for
#     the LED strip, so it's a hard requirement.
android.uses_feature =
    android.hardware.usb.host:required=false,
    android.hardware.bluetooth_le:required=true

[buildozer]
log_level = 2
warn_on_root = 1
