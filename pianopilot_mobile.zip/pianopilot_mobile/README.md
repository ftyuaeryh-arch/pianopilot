# PianoPilot Mobile

Kivy/Android port that merges your **PianoPilot** SysEx controller and
**Piano-LED-Visualizer**'s falling-notes/Wait-Mode logic into one app,
targeting the Galaxy A53 5G.

## Architecture

```
main.py                  Kivy App, 120Hz Clock.schedule_interval loop
piano_pilot.kv            landscape UI: canvas + control panel
core/
  roland_sysex.py         your exact DT1/RQ1/CC hex, ported to raw bytes
  android_midi.py         android.media.midi.MidiManager wrapper (USB + BLE)
  song_player.py          .mid loading (mido, file-parsing only) + SongClock
  wait_mode.py             freezes SongClock until the right keys are struck
  led_bridge.py            NoteOn/Off -> BLE-MIDI, note->LED calibration
ui/
  falling_notes.py         Kivy canvas widget, redrawn every frame
buildozer.spec
assets/device_filter.xml   optional USB-attach auto-launch filter
```

## Key design decision: one MIDI API for both transports

Rather than writing a raw USB-host bulk-transfer driver *and* a
separate BLE GATT client for MIDI (two very different codebases),
`android_midi.py` uses Android's built-in `android.media.midi.MidiManager`
(API 23+) via pyjnius. Since Android 8.0 (`minapi 26`, set in
buildozer.spec), MidiManager also auto-wraps a *paired* BLE-MIDI
peripheral as a regular `MidiDevice` — so the ESP32-C3 (once paired in
Android Bluetooth settings, assuming its firmware exposes the standard
BLE-MIDI GATT service) and the USB-OTG Roland connection are opened,
read and written through the exact same `MidiInputPort`/`MidiOutputPort`
calls. This removes GATT MTU/fragmentation handling and manual USB
endpoint parsing entirely — both were candidates for hard-to-debug
bugs if hand-rolled.

Your SysEx builders in `roland_sysex.py` are otherwise untouched:
same addresses, same checksums, same value ranges as your desktop
`messages.py` — only the transport changed from `mido.Message` (needs
rtmidi, unavailable on Android) to plain `bytes`.

## What I could not verify without your original PianoPilot repo

I ported this from `RolandFP30xController-main` (your Roland desktop
SysEx repo) and `Piano-LED-Visualizer-master`. Things you'll need to
fill in before this compiles/runs as-is:

1. **Hidden GS tone bank/program table** — `main.py::change_gs_tone`
   uses a placeholder bank (0x56/0). Swap in whatever bank/program
   list your desktop app's hidden-tone picker actually used.
2. **LED calibration values** — `LedCalibration()` in `main.py` is
   constructed with defaults; copy your real `leds_per_meter`,
   `led_number`, `reverse`, `shift` and `note_offsets` from your
   Piano-LED-Visualizer `usersettings`/`ledsettings` config.
3. **ESP32-C3 BLE-MIDI firmware** — this assumes the ESP32 advertises
   a standard BLE-MIDI GATT service (e.g. via Arduino `BLE-MIDI`
   library) and is *paired* beforehand in Android Bluetooth settings;
   MidiManager will not surface an unpaired peripheral.
4. **USB device filter** — see `assets/device_filter.xml`; buildozer
   has no spec key to auto-merge it, so it's a manual manifest patch
   (instructions inside the file) — purely cosmetic (controls the
   "open with PianoPilot?" system prompt), not required for the app
   to talk to the piano.
5. **pyjnius + android.media.midi** compiles fine with python-for-android's
   default recipes, but MidiManager access needs `USE_SDK_MIDI`-style
   care: test `openDevice` callback timing on your A53 specifically —
   Samsung's OneUI has been known to delay MIDI device enumeration by
   a second or two after a device is plugged in.

## Running on desktop for UI/logic dev

`android_midi.py` falls back to a no-op `_NullTransport` when pyjnius
isn't importable, so `main.py` boots on a regular PC (`python main.py`
with `kivy` and `mido` installed) for iterating on the falling-notes
canvas and song-loading logic without a phone attached.

## Build

```
pip install buildozer cython
buildozer -v android debug
adb install -r bin/pianopilotmobile-0.1.0-arm64-v8a-debug.apk
```
